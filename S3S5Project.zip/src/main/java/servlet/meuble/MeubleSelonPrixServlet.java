package servlet.meuble;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import database.PG;
import entity.meuble.VMeuble;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/meuble_selon_prix")
public class MeubleSelonPrixServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<VMeuble> vMeuble = new ArrayList<>();
        String prixMi = "";
        String prixMa = "";
        Connection connection = null;
        try {
            if (request.getParameter("prix_min") != null && request.getParameter("prix_max") != null) {
                Double prixMin = Double.parseDouble(request.getParameter("prix_min"));
                Double prixMax = Double.parseDouble(request.getParameter("prix_max"));
                prixMi = String.valueOf(prixMin);
                prixMa = String.valueOf(prixMax);
                connection = PG.getConnection();
                vMeuble = VMeuble.selectByPrixEntre(connection, prixMin, prixMax);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (Exception e) {
            }
        }
        request.setAttribute("prixMin", prixMi);
        request.setAttribute("prixMax", prixMa);
        request.setAttribute("vMeuble", vMeuble);
        request.getRequestDispatcher("meuble_selon_prix.jsp").forward(request, response);
    }
}
