package entity.meuble;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VMeuble {
    private Integer id;
    private String nom;
    private Integer idStyleMeuble;
    private Integer idCategorieMeuble;
    private String description;
    private String nomStyleMeuble;
    private String nomCategorieMeuble;
    private Double prixUnitaire;
    private String nomTailleMeuble;

    public VMeuble() {
    }

    public VMeuble(Integer id, String nom, Integer idStyleMeuble, Integer idCategorieMeuble, String description,
            String nomStyleMeuble, String nomCategorieMeuble) {
        setId(id);
        setNom(nom);
        setIdStyleMeuble(idStyleMeuble);
        setIdCategorieMeuble(idCategorieMeuble);
        setDescription(description);
        setNomStyleMeuble(nomStyleMeuble);
        setNomCategorieMeuble(nomCategorieMeuble);
    }

    

    public VMeuble(Integer id, String nom, Integer idStyleMeuble, Integer idCategorieMeuble, String description,
            String nomStyleMeuble, String nomCategorieMeuble, Double prixUnitaire) {
        this.id = id;
        this.nom = nom;
        this.idStyleMeuble = idStyleMeuble;
        this.idCategorieMeuble = idCategorieMeuble;
        this.description = description;
        this.nomStyleMeuble = nomStyleMeuble;
        this.nomCategorieMeuble = nomCategorieMeuble;
        this.prixUnitaire = prixUnitaire;
    }

    

    public VMeuble(Integer id, String nom, String description,
            String nomStyleMeuble, String nomCategorieMeuble, String nomTailleMeuble, Double prixUnitaire) {
        this.id = id;
        this.nom = nom;
        this.description = description;
        this.nomStyleMeuble = nomStyleMeuble;
        this.nomCategorieMeuble = nomCategorieMeuble;
        this.prixUnitaire = prixUnitaire;
        this.nomTailleMeuble = nomTailleMeuble;
    }

    public void setNomTailleMeuble(String nomTailleMeuble) {
        this.nomTailleMeuble = nomTailleMeuble;
    }

    public String getNomTailleMeuble() {
        return nomTailleMeuble;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Integer getIdStyleMeuble() {
        return idStyleMeuble;
    }

    public void setIdStyleMeuble(Integer idStyleMeuble) {
        this.idStyleMeuble = idStyleMeuble;
    }

    public Integer getIdCategorieMeuble() {
        return idCategorieMeuble;
    }

    public void setIdCategorieMeuble(Integer idCategorieMeuble) {
        this.idCategorieMeuble = idCategorieMeuble;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNomStyleMeuble() {
        return nomStyleMeuble;
    }

    public void setNomStyleMeuble(String nomStyleMeuble) {
        this.nomStyleMeuble = nomStyleMeuble;
    }

    public String getNomCategorieMeuble() {
        return nomCategorieMeuble;
    }

    public void setNomCategorieMeuble(String nomCategorieMeuble) {
        this.nomCategorieMeuble = nomCategorieMeuble;
    }

    public void setPrixUnitaire(Double prixUnitaire) {
        this.prixUnitaire = prixUnitaire;
    }

    public Double getPrixUnitaire() {
        return prixUnitaire;
    }

    public static List<VMeuble> list(Connection connection) throws SQLException {
        List<VMeuble> vMeubleList = new ArrayList<>();
        String query = "SELECT * FROM v_meuble";

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);

        while (resultSet.next()) {
            Integer id = resultSet.getInt("id");
            String nom = resultSet.getString("nom");
            Integer idStyleMeuble = resultSet.getInt("id_style_meuble");
            String description = resultSet.getString("description");
            String nomStyleMeuble = resultSet.getString("nom_style_meuble");
            String nomCategorieMeuble = resultSet.getString("nom_categorie_meuble");
            Integer idCategorieMeuble = resultSet.getInt("id_categorie_meuble");

            VMeuble vMeuble = new VMeuble(id, nom, idStyleMeuble, idCategorieMeuble, description, nomStyleMeuble,
                    nomCategorieMeuble);
            vMeubleList.add(vMeuble);
        }
        statement.close();
        resultSet.close();
        return vMeubleList;
    }

    public static VMeuble selectById(Connection connection, Integer id) throws SQLException {
        String query = "SELECT * FROM v_meuble WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            String nom = resultSet.getString("nom");
            Integer idStyleMeuble = resultSet.getInt("id_style_meuble");
            Integer idCategorieMeuble = resultSet.getInt("id_categorie_meuble");
            String description = resultSet.getString("description");
            String nomStyleMeuble = resultSet.getString("nom_style_meuble");
            String nomCategorieMeuble = resultSet.getString("nom_categorie_meuble");
            VMeuble vMeuble = new VMeuble(id, nom, idStyleMeuble, idCategorieMeuble,
                    description, nomStyleMeuble, nomCategorieMeuble);
            return vMeuble;
        }
        return null;
    }

    public static List<VMeuble> selectByPrixEntre(Connection connection,Double prixMin,Double prixMax) throws Exception{
        List<VMeuble> vMeubleList = new ArrayList<>();
        String query = "\r\n" + //
                "select m.id,m.nom,cm.nom as nom_categorie_meuble,sm.nom as nom_style_meuble,tm.nom as nom_taille_meuble,m.description,r4.pt from (\r\n" + //
                "select * from (\r\n" + //
                "select r2.id_formule_meuble,sum(r2.pt) as pt from (\r\n" + //
                "select r1.*, r1.quantite*r1.pu as pt from \r\n" + //
                "(select dfm.*,m.prix_unitaire as pu from detail_formule_meuble dfm join materiau m on m.id=dfm.id_materiau) as r1) as r2 group by r2.id_formule_meuble) as r3\r\n" + //
                "where r3.pt >= "+prixMin+" and r3.pt <= "+prixMax+" ) as r4\r\n" + //
                "join formule_meuble fm on fm.id=r4.id_formule_meuble\r\n" + //
                "join taille_meuble tm on tm.id=fm.id_taille_meuble\r\n" + //
                "join meuble m on m.id=fm.id_meuble\r\n" + //
                "join categorie_meuble cm on cm.id=m.id_categorie_meuble\r\n" + //
                "join style_meuble sm on sm.id=m.id_style_meuble\r\n" + //
                ";\r\n" + //
                "";

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);

        while (resultSet.next()) {
            Integer id = resultSet.getInt("id");
            String nom = resultSet.getString("nom");
            // Integer idStyleMeuble = resultSet.getInt("id_style_meuble");
            String description = resultSet.getString("description");
            String nomStyleMeuble = resultSet.getString("nom_style_meuble");
            String nomCategorieMeuble = resultSet.getString("nom_categorie_meuble");
            // Integer idCategorieMeuble = resultSet.getInt("id_categorie_meuble");
            String nomTailleMeuble = resultSet.getString("nom_taille_meuble");
            double prixUnitaire = resultSet.getDouble("pt");

            VMeuble vMeuble = new VMeuble(id, nom, description, nomStyleMeuble,
                    nomCategorieMeuble,nomTailleMeuble, prixUnitaire);
            vMeubleList.add(vMeuble);
        }
        statement.close();
        resultSet.close();
        return vMeubleList;
    }

}
